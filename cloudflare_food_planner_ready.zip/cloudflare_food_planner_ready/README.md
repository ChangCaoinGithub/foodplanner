# Food Planner — Cloudflare Pages + D1

This version does NOT use Supabase.

The public GitHub repository contains only frontend code and backend logic.
Your actual allowed family emails live only in the private Cloudflare D1 database.

## Architecture

Browser -> /api/login -> Cloudflare Pages Function -> D1 allowed_users

The backend returns only allowed / denied. It never returns the allowed email list.

When an email is accepted, the backend creates a random 180-day session and sends it
as an HttpOnly + Secure + SameSite=Lax cookie. JavaScript cannot read that cookie.
Later API calls must have a valid session before they can read or change food data.

## 1. Put this project on GitHub

Upload the project folders exactly like this:

    functions/
      api/
        [[path]].js
    public/
      index.html
      _routes.json
    schema.sql
    README.md

Do NOT put your real allowed emails into schema.sql before making the repo public.

## 2. Create a Cloudflare Pages project

Cloudflare Dashboard -> Workers & Pages -> Create -> Pages -> Connect to Git.

Choose your GitHub repository.

Use:

    Framework preset: None
    Build command: leave empty
    Build output directory: public

Deploy once.

Cloudflare Pages Functions are taken from the root /functions directory automatically.

## 3. Create a D1 database

Cloudflare Dashboard -> Storage & databases -> D1 -> Create database.

Name it, for example:

    food-planner-db

Open its Console and paste/run the contents of schema.sql.

## 4. Add your allowed family emails privately

In the D1 database Console, run lines like:

    INSERT INTO allowed_users(email) VALUES ('your-real-email@example.com');
    INSERT INTO allowed_users(email) VALUES ('family-member@example.com');

These commands are run in Cloudflare's private database console. They are NOT added to
GitHub and are NOT visible in index.html.

To see who is allowed, only you can query in the Cloudflare console:

    SELECT * FROM allowed_users;

To remove access:

    DELETE FROM allowed_users WHERE email = 'someone@example.com';

## 5. Bind D1 to the Pages project

Open:

    Workers & Pages -> your Pages project -> Settings -> Bindings

Add a D1 database binding.

Use EXACTLY this variable name:

    DB

Select your food-planner-db database.

Save it, then redeploy the Pages project. Cloudflare's current Pages docs require a
redeploy after a new D1 binding is added.

## 6. Open your Pages URL

It will look like:

    https://your-project.pages.dev

First visit on a device:

    Enter your email -> Continue

If the value exists in allowed_users, the backend creates a session and the Food Planner
opens immediately. No email is sent. No Magic Link exists.

For the next 180 days on that browser, it normally opens directly.

## Privacy / security model

- Allowed email list: only in D1 backend
- index.html: contains NO allowed list
- API: returns only success/failure
- Session cookie: HttpOnly, Secure, SameSite=Lax
- Raw session token: never stored in D1; only its SHA-256 hash is stored
- Failed login attempts: basic rate limit, 12 attempts / 15 minutes / IP
- IP addresses: only a SHA-256 hash is temporarily stored for rate limiting

Important: you intentionally use an email string as a family access secret. Anyone who
guesses one of the allowed values can enter. This is appropriate only for low-sensitivity
household data such as fridge contents and meal plans.

## Shared updates

All devices read and write the same D1 database. The frontend refreshes shared data:
- immediately after an edit
- when the browser tab becomes active
- every 10 seconds while the page is open
